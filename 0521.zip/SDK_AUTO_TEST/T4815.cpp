#include "UNIT_INC.h"
#include "SdkFunction.h"
#include "ScriptTester.h"

class TEST_T4815 : public ::testing::Test {
 public: // NOLINT
	virtual void SetUp() {
		SdkFunction::GetInstance()->SetScriptName(SdkFunction::kT4815);
		SdkFunction::GetInstance()->SetCopyDbCommend(SdkFunction::kT4815);
		SdkFunction::GetInstance()->CheckHRSSRobotType(SdkFunction::kT4815);
		SdkFunction::GetInstance()->SetCounterInital();
		SdkFunction::GetInstance()->SetDoInital();
		SdkFunction::GetInstance()->JogHome();
		SdkFunction::GetInstance()->SetHRSSHrb();
		SdkFunction::GetInstance()->StartHRSSHrb();

	}

	virtual void TearDown() {
		SdkFunction::GetInstance()->SetCounterInital();
		SdkFunction::GetInstance()->StopHRSSHrb();
	}
};

TEST_F(TEST_T4815, StartPauseTest) {
	ScriptTester scripttester;
	//use unique_ptr to avoid forgeting delete
	unique_ptr<ScriptTest> task(scripttester.CreateTest(SdkFunction::SQA::kT4815, kTime));
	ASSERT_EQ(task->GetResult(), TEST_SUCCESS);
}