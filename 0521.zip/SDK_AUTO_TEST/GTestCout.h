#ifndef _GTEST_COUT_H_
#define _GTEST_COUT_H_

#include "gtest/gtest.h"

namespace testing {
namespace internal {
enum GTestColor {
	COLOR_DEFAULT,
	COLOR_RED,
	COLOR_GREEN,
	COLOR_YELLOW,
};
extern void ColoredPrintf(GTestColor color, const char* fmt, ...);
}
}

#define GCOUT(STREAM) \
    do \
    { \
        std::stringstream ss; \
        ss << STREAM << std::endl; \
        testing::internal::ColoredPrintf(testing::internal::COLOR_YELLOW, "[     info ] "); \
        testing::internal::ColoredPrintf(testing::internal::COLOR_YELLOW, ss.str().c_str()); \
    } while (false); \

#define GCOUTERROR(STREAM) \
    do \
    { \
        std::stringstream ss; \
        ss << STREAM << std::endl; \
        testing::internal::ColoredPrintf(testing::internal::COLOR_RED, "[     fail ] "); \
        testing::internal::ColoredPrintf(testing::internal::COLOR_RED, ss.str().c_str()); \
    } while (false); \

#endif /* _GTEST_COUT_H_ */

