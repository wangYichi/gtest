#include "UNIT_INC.h"
#include "SdkFunction.h"

template bool SdkFunction::IsPositionEqual<double>(double current_position[], double home_point[], bool is_ra) const;
template bool SdkFunction::IsPositionEqual<int>(int current_position[], int home_point[], bool is_ra) const;
bool task_abort_flag = false;

void __stdcall CallBack(uint16_t cmd, uint16_t rlt, uint16_t* Msg, int len) {
	switch (cmd) {
	case 4004:
		if (rlt == 4018) {
			task_abort_flag = true;
		}
		break;
	default:
		break;
	}
}

SdkFunction::SdkFunction() {
}

SdkFunction::~SdkFunction() {
}

void SdkFunction::CloseHRSS() {
	system("taskkill /f /im HRSS.exe");
	Sleep(500);
}

void SdkFunction::CloseHRSSCrash() {
	system("taskkill /f /im HRSS.exe | taskkill /f /im HRSS_.exe");
	Sleep(500);
}

void SdkFunction::OpenHRSS() {
	system("cd.. & start HRSS.exe");
	Sleep(500);
}

void SdkFunction::CopyDB() {
	system(commend.c_str());
	Sleep(500);
}

void SdkFunction::CloseByTcpClient() {
	GCOUT("tcp client is close");
	mb.modbus_close();
}

void SdkFunction::TcpClientWriteCoil(uint16_t address, bool coil) {
	//HRSS SI channel1 0-127
	mb.modbus_write_coil(address, coil);
	//mb.modbus_read_coils(start_address, amount, coils);
}

void SdkFunction::TcpClientReadInputs(uint16_t start_address, uint16_t amount, bool* inputs) {
	//HRSS SO channel1 0-127
	mb.modbus_read_input_bits(start_address, amount, inputs);
}

void SdkFunction::TcpClientSetSpeedRatio(int ratio) {
	mb.modbus_write_register(100, ratio);
	while (!(GetOverrideRatio() == ratio)) {
	}
}

void SdkFunction::GetCurrentRpm(double* rpm) {
	get_current_rpm(device_id, rpm);
}

void SdkFunction::GetExtCurrentRpm(double* ext_rpm) {
	//get_current_ext_rpm(device_id, ext_rpm);
}

void SdkFunction::GetExtCurrentPos(double* ext_pos) {
	get_current_ext_pos(device_id, ext_pos);
}

bool SdkFunction::TcpClientJogHome() {
	time_t begin_time, end_time, wait_time = 0;
	double current_position[6] = { 0 };
	uint16_t write_regs[] = { 4, 1 };

	WaitForStopMotion();
	//set command
	mb.modbus_write_registers(201, 2, write_regs);
	//run
	write_regs[0] = 1;
	mb.modbus_write_registers(200, 1, write_regs);

	time(&begin_time);

	do {
		auto wait_time = difftime(time(&end_time), begin_time);//unit:SEC
		if (wait_time > MAX_WAITING_TIME) {
			GCOUTERROR("TcpClientJogHome Fail");
			return TEST_ERROR;
			break;
		}
		get_current_joint(device_id, current_position);
	} while (!IsPositionEqual(current_position, (is_ra ? ra_joint_home : rs_joint_home), is_ra));

	//stop
	write_regs[0] = 0;
	mb.modbus_write_registers(200, 1, write_regs);
	WaitForStopMotion();

	return TEST_SUCCESS;
}

void SdkFunction::TcpClientJog(JointCoordinates coord, SpaceOperationDirection dir, int delay) {
	time_t begin_time, end_time, wait_time = 0;
	uint16_t write_regs[] = { 3, coord, dir };

	//set command
	mb.modbus_write_registers(201, 3, write_regs);
	//run
	write_regs[0] = 1;
	mb.modbus_write_registers(200, 1, write_regs);

	time(&begin_time);

	while (wait_time < delay) {
		wait_time = difftime(time(&end_time), begin_time);
	}
	//stop
	write_regs[0] = 0;
	mb.modbus_write_registers(200, 1, write_regs);
}

bool SdkFunction::ConnectByTcpClient() {
	mb.modbus_set_slave_id(mobus_id);
	bool is_mobus_connect = mb.modbus_connect();
	if (is_mobus_connect) {
		GCOUT("tcp client is connected");
	} else {
		GCOUTERROR("tcp client connect fail");
	}
	return is_mobus_connect;
}

bool SdkFunction::MotionHold() {
	return motion_hold(device_id);
}

bool SdkFunction::MotionContinue() {
	return motion_continue(device_id);
}

bool SdkFunction::CreateFolder(char* folder_name) {
	return new_folder(device_id, folder_name);
}

bool SdkFunction::DeleteFolder(char* folder_name) {
	return delete_folder(device_id, folder_name);
}

bool SdkFunction::IsRaSeries() {
	return is_ra;
}

//bool SdkFunction::SetHrssMode(OperationMode mode) {
//	if (get_hrss_mode(device_id) == mode) {
//		return TEST_SUCCESS;
//	}
//
//	do {
//		set_hrss_t1_aut_mode(device_id);
//		Sleep(1000);
//	} while (get_hrss_mode(device_id) != mode);
//
//	return get_hrss_mode(device_id) != mode;
//}

bool CheckRobotType(SdkFunction::SQA task, std::string robot_type, bool second_test) {
	string temp_robot_type = "";
	switch (task) {
	case SdkFunction::SQA::kT4815:
	case SdkFunction::SQA::kT5587:
		temp_robot_type = RS410_600_200_LU;
		break;
	case SdkFunction::SQA::kT5717:
		temp_robot_type = RS405_500_200_LU;
		break;
	case SdkFunction::SQA::kItalySpeedTest:
		temp_robot_type = RS405_400_200_LU;
		break;
	case SdkFunction::SQA::kT6083:
		if (second_test) {
			temp_robot_type = RS405_400_200_LU;
		} else {
			temp_robot_type = RA605_710_GC;
		}
		break;
	case SdkFunction::SQA::kDegreeMoveTest:
	case SdkFunction::SQA::kPosMoveTest:
		if (second_test) {
			temp_robot_type = RA605_710_GC;
		} else {
			temp_robot_type = RS405_400_200_LU;
		}
		break;
	case SdkFunction::SQA::kShutdownTest:
	case SdkFunction::SQA::kT4817:
	case SdkFunction::SQA::kT4884:
	case SdkFunction::SQA::kT6370:
	case SdkFunction::SQA::kT5462:
	default:
		temp_robot_type = RA605_710_GC;
		break;
	}

	return robot_type == temp_robot_type;
}


bool SdkFunction::OpenConnection() {
	device_id = open_connection(IP, 1, CallBack);
	is_connected = device_id >= 0 ? true : false;
	if (is_connected) {
		GCOUT("Connect HRSS");
		set_connection_level(device_id, kController);
		SetOperationMode(kManual);
	}

	return is_connected;
}

bool SdkFunction::SetOperationMode(OperationModes mode) {
	bool check = TEST_ERROR;
	if (!is_connected) {
		GCOUTERROR("HRSS SDK Disconnetcd!");
		return TEST_ERROR;
	} else {
		check = set_operation_mode(device_id, mode);
	}


	return check;
}

bool SdkFunction::DirExists(string path) {
	struct stat info;
	if (stat(path.c_str(), &info) == 0 && info.st_mode & S_IFDIR) {
		return true;
	}
	return false;
}

bool SdkFunction::CheckHRSSRobotType(SQA task, bool second_test) {
	int get_robot = -1;

	if (GetRobotType() != TEST_SUCCESS) {
		return TEST_ERROR;
	}

	if (CheckRobotType(task, robot_type, second_test)) {
		return TEST_SUCCESS;
	} else {
		CloseHRSS();
		CopyDB();
		OpenHRSS();

		is_connected = ReConnection();

		if (is_connected) {
			GCOUT("Reconnect HRSS");
			return GetRobotType();
		}
	}
}

bool SdkFunction::ReConnection() {
	int connect_count = 0;
	bool connected = false;

	if (is_connected) {
		disconnect(device_id);
		is_connected = false;
	}

	do {
		Sleep(1000 * 60);
		connected = OpenConnection();
		if (connect_count >= CONNECT_COUNT) {
			break;
		}
		connect_count++;
		message = "Reconnect HRSS: " + to_string(connect_count);
		GCOUT(message);
	} while (!connected);

	return connected;
}

void SdkFunction::SetUserAlarmMessage(int index, string message) {
	char* msg = new char[256];
	time_t begin_time, end_time;
	time(&begin_time);

	do {
		set_user_alarm_setting_message(device_id, index, &*message.begin());
		get_user_alarm_setting_message(device_id, index, msg);
		auto wait_time = difftime(time(&end_time), begin_time);
		if (wait_time >= MAX_WAITING_TIME) { // Do not wait forever
			break;  // Movement hasn't stop for a long time!
		}
	} while (!(string(msg) == message));
	delete msg;
}

template<class T>
bool SdkFunction::IsPositionEqual(T current_position[], T home_point[], bool is_ra) const {
	bool check = false;
	switch (is_ra) {
	case true:
		check = fabs(current_position[0] - home_point[0]) < POSITION_ERROR &&
		        fabs(current_position[1] - home_point[1]) < POSITION_ERROR &&
		        fabs(current_position[2] - home_point[2]) < POSITION_ERROR &&
		        fabs(current_position[3] - home_point[3]) < POSITION_ERROR &&
		        fabs(current_position[4] - home_point[4]) < POSITION_ERROR &&
		        fabs(current_position[5] - home_point[5]) < POSITION_ERROR;
		break;
	case false:
		check = fabs(current_position[0] - home_point[0]) < POSITION_ERROR &&
		        fabs(current_position[1] - home_point[1]) < POSITION_ERROR &&
		        fabs(current_position[2] - home_point[2]) < POSITION_ERROR &&
		        fabs(current_position[3] - home_point[3]) < POSITION_ERROR;
		break;
	default:
		break;
	}
	return check;
}

bool SdkFunction::WaitForStopMotion() {
	time_t begin_time, end_time;
	time(&begin_time);
	while (GetMotionState() != RobotMotionStatus::kIdle && get_motion_state(device_id) != 0) {
		auto wait_time = difftime(time(&end_time), begin_time);
		if (get_connection_level(device_id) == ConnectionLevels::kDisconnection) {
			return false;  // The robot is not connected anymore
		}
		if (wait_time >= MAX_WAITING_TIME) { // Do not wait forever
			return false;  // Movement hasn't stop for a long time!
		}
	}
	return true;
}

int SdkFunction::SetOverrideRatio(int ratio) {
	int check = set_override_ratio(device_id, ratio);
	while (!(GetOverrideRatio() == ratio)) {
	}
	return check;
}

int SdkFunction::GetRobotType() {
	char* robot = new char[256];
	int check = get_robot_type(device_id, robot);
	robot_type = string(robot);
	if (check == TEST_SUCCESS) {
		if (robot_type.find("RA") != string::npos) {
			is_ra = true;
		} else if (robot_type.find("RS") != string::npos) {
			is_ra = false;
		}
	}
	delete robot;
	return check;
}

int SdkFunction::GetHRSSVersion() {
	char* version = new char[256];
	int rlt = get_hrss_version(device_id, version);
	string temp(version);

	if (temp.find("3.3.") != string::npos) {
		hrss_version = kHRSS33;
	} else if (temp.find("3.4.") != string::npos) {
		hrss_version = kHRSS40;
	}
	delete[] version;
	return rlt;
}

int SdkFunction::GetHRSSMode() {
	return get_hrss_mode(device_id);
}

int SdkFunction::ClearAlarm() {
	int check = clear_alarm(device_id);
	return check;
}

void StringSplit(const std::string & s, const char delim,
                 std::vector<std::string> &out) {
	std::string::size_type beg = 0;
	for (auto end = 0; (end = s.find(delim, end)) != std::string::npos; ++end) {
		out.push_back(s.substr(beg, end - beg));
		beg = end + 1;
	}

	out.push_back(s.substr(beg));
}

vector<vector<double>> SdkFunction::ReadCsv(string file_name) {
	vector<std::string> out;
	std::vector<double> temp;
	vector<vector<double>> point;
	string line;
	int pos = 0;
	char delim = ',';

	ifstream inFile(file_name, ios::in);
	if (!inFile) {
		GCOUTERROR("Open file fail�I");
		exit(1);
	}
	while (getline(inFile, line)) {
		StringSplit(line, delim, out);
		for (auto &s : out) {
			temp.push_back(stod(s));
		}
		point.push_back(temp);
		out.clear();
		temp.clear();
	}
	return point;
}

void SdkFunction::SetScriptName(SQA task) {
	std::string temp_script;
	switch (task) {
	case kT4815:
		temp_script = "SQA\\T4815\\T4815.hrb";
		break;
	case kT4817:
		temp_script = "SQA\\T4817\\T4817.hrb";
		break;
	case kT4884:
		temp_script = "SQA\\T4884\\T4884.hrb";
		break;
	case kT5717:
		temp_script = "SQA\\T5717\\T5717.hrb";
		break;
	case kT5587:
		temp_script = "SQA\\T5587\\T5587.hrb";
		break;
	case kT6083:
		temp_script = "SQA\\T6083\\T6083.hrb";
		break;
	case kT6370:
		temp_script = "SQA\\T6370\\T6370.hrb";
		break;
	case kStartStopPauseTest:
		temp_script = "SQA\\StartStopPause\\StartStopPause.hrb";
		break;
	case kSpeedTest:
		temp_script = "SQA\\Speed\\Speed.hrb";
		break;
	default:
		temp_script = "";
		break;
	}

	strcpy_s(script_name, temp_script.c_str());
}

void SdkFunction::SetCopyDbCommend(SQA task, bool second_test) {
	switch (task) {
	case kT4815:
		commend = "copy SQA\\T4815\\*.db ..\\ /Y /V";
		break;
	case kT4817:
		commend = "copy SQA\\T4817\\*.db ..\\ /Y /V";
		break;
	case kT4884:
		commend = "copy SQA\\T4884\\*.db ..\\ /Y /V";
		break;
	case kT5717:
		commend = "copy SQA\\T5717\\*.db ..\\ /Y /V";
		break;
	case kT5587:
		commend = "copy SQA\\T5587\\*.db ..\\ /Y /V";
		break;
	case kT6083:
		if (second_test) {
			commend = "copy SQA\\T6083\\RS\\*.db ..\\ /Y /V";
		} else {
			commend = "copy SQA\\T6083\\RA\\*.db ..\\ /Y /V";
		}
		break;
	case kT6370:
		commend = "copy SQA\\T6370\\*.db ..\\ /Y /V";
		break;
	case kItalySpeedTest:
		commend = "copy SQA\\ItelySpeedTest\\*.db ..\\ /Y /V";
		break;
	case kDegreeMoveTest:
		if (second_test) {
			commend = "copy SQA\\DegreeMove\\RA\\*.db ..\\ /Y /V";
		} else {
			commend = "copy SQA\\DegreeMove\\RS\\*.db ..\\ /Y /V";
		}
		break;
	case kPosMoveTest:
		if (second_test) {
			commend = "copy SQA\\PosMove\\RA\\*.db ..\\ /Y /V";
		} else {
			commend = "copy SQA\\PosMove\\RS\\*.db ..\\ /Y /V";
		}
		break;
	default:
		commend = "";
		break;
	}
}

int SdkFunction::SetCounterInital() {
	int counter_index[20] { 0 };
	int value_index[20] { 0 };
	for (int i = 0; i < sizeof(counter_index) / sizeof(int); i++) {
		counter_index[i] = i + 1;
	}
	return set_counter_array(device_id, counter_index, value_index, sizeof(counter_index) / sizeof(int));;
}

int SdkFunction::SetCounter(int index, int value) {
	return set_counter(device_id, index, value);
}

int SdkFunction::JogHome() {
	time_t begin_time, end_time, wait_time = 0;
	bool check = false;
	double current_position[6] = { 0 };

	WaitForStopMotion();
	get_current_joint(device_id, current_position);
	if (IsPositionEqual(current_position, (is_ra ? ra_joint_home : rs_joint_home), is_ra)) {
		return TEST_SUCCESS;
	} else {
		time(&begin_time);
		check = jog_home(device_id);
		set_override_ratio(device_id, 50);
		while (GetMotionState() != RobotMotionStatus::kRunning) {
			wait_time = difftime(time(&end_time), begin_time);
			if (wait_time > MAX_WAITING_TIME || check) {
				GCOUTERROR("JogHome Fail!");
				return TEST_ERROR;
			}
		}
	}

	do {
		auto wait_time = difftime(time(&end_time), begin_time);//unit:SEC
		if (wait_time > MAX_WAITING_TIME) {
			return TEST_ERROR;
		}
		get_current_joint(device_id, current_position);
	} while (!IsPositionEqual(current_position, (is_ra ? ra_joint_home : rs_joint_home), is_ra));
	set_override_ratio(device_id, 10);
	WaitForStopMotion();
	return TEST_SUCCESS;
}

int SdkFunction::SetRSR(int index) {
	char* file_name = new char[128];
	do {
		set_rsr(device_id, HRB_NAME, index);
		get_rsr_prog_name(device_id, 1, file_name);
	} while (string(file_name) != HRB_NAME);
	delete file_name;
	return TEST_SUCCESS;
}


int SdkFunction::SetMobusServerConfig(char* local_ip1, char* local_ip2, int local_port) {
	//int check = set_modbus_server_config(device_id, local_ip1, local_ip2, local_port);
	int check = true;
	return check;
}

int SdkFunction::OpenMobusServer(int slave_num, bool connection) {
	int check = true;
	//int check = modbus_server_connection(device_id, slave_num, connection);
	return check;
}

int SdkFunction::MobusClientConnection(int slave_num, bool connection) {
	int check = true;
	//int check = modbus_client_connection(device_id, slave_num, connection);
	return check;
}

int SdkFunction::SetMobusClientConfig(int channel, int server_num, char* remote_ip, int remote_port,
                                      int input_begin, int input_size, int output_begin, int output_size,
                                      int register_begin, int register_size, int in_reg_begin, int in_reg_size) {
	//int check = set_modbus_client_config(device_id, channel, server_num, remote_ip, remote_port, input_begin, input_size,
	//                                   output_begin, output_size, register_begin, register_size, in_reg_begin, in_reg_size);
	int check = true;
	return check;
}

int SdkFunction::SetHRSSHrb() {
	int check = send_file(device_id, script_name, HRB_NAME);
	Sleep(500);
	return check;
}

int SdkFunction::StartHRSSHrb() {
	time_t begin_time, end_time, wait_time = 0;
	int check = false;

	WaitForStopMotion();
	time(&begin_time);
	check = task_start(device_id, HRB_NAME);
	while (get_motion_state(device_id) != RobotMotionStatus::kRunning) {
		wait_time = difftime(time(&end_time), begin_time);
		if (wait_time >= MAX_WAITING_TIME) {
			return false;
		}

		check = task_start(device_id, HRB_NAME);
	}
	return check;
}

int SdkFunction::ExtStartHRSSHrb() {
	time_t begin_time, end_time, wait_time = 0;
	bool check = false;

	WaitForStopMotion();
	time(&begin_time);
	while (GetMotionState() != RobotMotionStatus::kRunning) {
		wait_time = difftime(time(&end_time), begin_time);
		if (wait_time >= MAX_WAITING_TIME) {
			return false;
		}

		check = ext_task_start(device_id, RSR, 1);
	}
	return check;
}

int SdkFunction::StopHRSSHrb() {
	task_abort_flag = false;
	bool check = task_abort(device_id);
	while (!(task_abort_flag == true)) {
		break;
	};
	return check;
}

int SdkFunction::TaskHold() {
	return task_hold(device_id);
}

int SdkFunction::TaskContinue() {
	return task_continue(device_id);
}

int SdkFunction::GetCounterValue(int index) {
	return get_counter(device_id, index);
}

int SdkFunction::GetCurrentPosition(double * position) {
	return get_current_position(device_id, position);
}

int SdkFunction::GetCurrentJoint(double * position) {
	return get_current_joint(device_id, position);
}

int SdkFunction::SetDoInital() {
	int do_index[20] { 0 };
	int value_index[20] { 0 };
	for (int i = 0; i < sizeof(do_index) / sizeof(int); i++) {
		do_index[i] = i + 1;
	}
	return set_DO_array(device_id, do_index, value_index, sizeof(do_index) / sizeof(int));
}

int SdkFunction::SetDiInital() {
	int di_index[20] { 0 };
	int value_index[20] { 0 };
	for (int i = 0; i < sizeof(di_index) / sizeof(int); i++) {
		di_index[i] = i + 1;
	}
	return set_DI_array(device_id, di_index, value_index, sizeof(di_index) / sizeof(int));
}

bool SdkFunction::SetDiValue(int index, bool value) {
	bool set_si_sim = false;
	bool set_si = false;
	Sleep(500);
	set_si_sim = set_DI_simulation_Enable(device_id, index, value);
	message = "Set DI Sim Error : " + to_string(set_si_sim);
	if (set_si_sim) {
		GCOUTERROR(message);
		return TEST_ERROR;
	}

	GCOUT("Set DI Sim Success");

	if (value && !set_si_sim) {
		Sleep(500);
		set_si = set_DI_simulation(device_id, index, value);
		message = "Set DI Error : " + to_string(set_si);
		if (set_si) {
			GCOUT(message);
		}
		return set_si;
	}

	return set_si_sim || set_si;
}

bool SdkFunction::PTPAxisCheck(int mode, double * pos) {
	time_t begin_time, end_time;
	double current_position[6] = { 0 };

	WaitForStopMotion();
	bool check = ptp_axis(device_id, mode, pos);
	if (check) {
		return TEST_ERROR;
	}
	time(&begin_time);

	do {
		auto wait_time = difftime(time(&end_time), begin_time);//unit:SEC
		if (wait_time > MAX_WAITING_TIME) {
			return TEST_ERROR;
		}
		get_current_joint(device_id, current_position);
	} while (!IsPositionEqual(current_position, pos, is_ra));

	WaitForStopMotion();
	return TEST_SUCCESS;
}

bool SdkFunction::PTPAxis(int mode, double * pos) {
	do {
		ptp_axis(device_id, mode, pos);
	} while (GetMotionState() != RobotMotionStatus::kRunning);

	return TEST_SUCCESS;
}

bool SdkFunction::PTPPosCheck(int mode, double * pos) {
	time_t begin_time, end_time;
	double current_position[6] = { 0 };
	bool check = ptp_pos(device_id, mode, pos);

	time(&begin_time);
	if (check) {
		return TEST_ERROR;
	}

	do {
		auto wait_time = difftime(time(&end_time), begin_time);//unit:SEC
		if (wait_time > MAX_WAITING_TIME) {
			return TEST_ERROR;
		}
		get_current_position(device_id, current_position);
	} while (!IsPositionEqual(current_position, pos, true));

	WaitForStopMotion();
	return TEST_SUCCESS;
}

bool SdkFunction::LineAxisCheck(int mode, int smooth_value, double * pos) {
	time_t begin_time, end_time;
	double current_position[6] = { 0 };

	WaitForStopMotion();
	bool check = lin_axis(device_id, mode, smooth_value, pos);
	if (check) {
		return TEST_ERROR;
	}
	time(&begin_time);

	do {
		auto wait_time = difftime(time(&end_time), begin_time);//unit:SEC
		if (wait_time > MAX_WAITING_TIME) {
			return TEST_ERROR;
		}
		get_current_joint(device_id, current_position);
	} while (!IsPositionEqual(current_position, pos, is_ra));

	WaitForStopMotion();
	return TEST_SUCCESS;
}

void SdkFunction::SetLineSpeed(double speed) {
	double get_line_speed = 0.0;
	//speed = speed > 250 ? 250 : speed;
	set_lin_speed(device_id, speed);
}

void SdkFunction::SetAccTime(double time) {
	double acc_time = 0.0;

	while (acc_time != time) {
		set_acc_time(device_id, time);
		acc_time = get_acc_time(device_id);
	}
}

bool SdkFunction::LinePosCheck(int mode, double smooth_value, double * pos) {
	time_t begin_time, end_time;
	double current_position[6] = { 0 };
	bool check = lin_pos(device_id, mode, smooth_value, pos);

	time(&begin_time);
	if (check) {
		return TEST_ERROR;
	}

	do {
		auto wait_time = difftime(time(&end_time), begin_time);//unit:SEC
		if (wait_time > MAX_WAITING_TIME) {
			return TEST_ERROR;
		}
		get_current_position(device_id, current_position);
	} while (!IsPositionEqual(current_position, pos, true));

	WaitForStopMotion();
	return TEST_SUCCESS;
}

bool SdkFunction::LinePos(int mode, double smooth_value, double * pos, bool is_6axis_pos) {
	double current_position[6] = { 0 };
	bool check = lin_pos(device_id, mode, smooth_value, pos);

	if (check) {
		return TEST_ERROR;
	}

	//WaitForStopMotion();
	return TEST_SUCCESS;
}

bool SdkFunction::WaitAxisArrived(double * pos) {
	double current_position[6] = { 0 };
	time_t begin_time, end_time;
	time(&begin_time);

	do {
		auto wait_time = difftime(time(&end_time), begin_time);//unit:SEC
		if (wait_time > MAX_WAITING_TIME) {
			return TEST_ERROR;
		}
		get_current_joint(device_id, current_position);
	} while (!IsPositionEqual(current_position, pos, is_ra));
	WaitForStopMotion();
	return TEST_SUCCESS;
}

int SdkFunction::GetDoValue(int index) {
	int do_value[DIO_END] = { 0 };
	get_DO_range(device_id, DIO_START, DIO_END, do_value);
	return do_value[index];
}

int SdkFunction::SetTrackEncoderSimulation(bool status) {
	int check = true;
	//int check = set_track_enconder_simulation(device_id, status);
	return check;
}

int SdkFunction::SetTrackTriggerSimulation(bool status) {
	int check = true;
	//int check = set_track_trigger_simulation(device_id, status);
	return check;
}

int SdkFunction::Jog(SpaceOperationTypes space_type, int index, SpaceOperationDirection dir, int delay_time) {
	time_t begin_time, end_time, wait_time = 0;
	int check;
	time(&begin_time);
	check = jog(device_id, space_type, index, dir);
	while (wait_time < delay_time) {
		wait_time = difftime(time(&end_time), begin_time);
	}
	jog_stop(device_id);
	return check;
}

int SdkFunction::GetOverrideRatio() {
	return get_override_ratio(device_id);
}

int SdkFunction::GetMotionState() {
	return get_motion_state(device_id);
}

int SdkFunction::SetMotionState(MotionState state) {
	int check = set_motor_state(device_id, state);
	Sleep(500);
	return check;
}

int SdkFunction::T6083ExtSetting() {
	int ext_int_valure[3] { 0, 5000, 131072 };
	double ext_double_valure[3] { 300.0, 1.0, 10.0 };

	if (set_ext_axis_setting_advanced(device_id, 0, 0, 0, 0, ext_int_valure, ext_double_valure) == TEST_SUCCESS) {
		if (set_ext_axis_setting(device_id, 0, true, 0, 2000.0, -100.0) != TEST_SUCCESS) {
			return TEST_ERROR;
		}
	} else {
		return TEST_ERROR;
	}

	ext_double_valure[1] = 80.0;
	ext_double_valure[2] = 360.0;
	if (set_ext_axis_setting_advanced(device_id, 1, 1, 0, 0, ext_int_valure, ext_double_valure) == TEST_SUCCESS) {
		if (set_ext_axis_setting(device_id, 1, true, 0, 360.0, -360.0) != TEST_SUCCESS) {
			return TEST_ERROR;
		}
	} else {
		return TEST_ERROR;
	}

	for (int i = 1; i < 3; i++) {
		ext_int_valure[i] = 1;
		ext_double_valure[i] = 1.0;
	}
	ext_double_valure[0] = 100.0;
	if (set_ext_axis_setting_advanced(device_id, 2, 0, 0, 0, ext_int_valure, ext_double_valure) == TEST_SUCCESS) {
		if (set_ext_axis_setting(device_id, 2, false, 0, 0.0, 0.0) != TEST_SUCCESS) {
			return TEST_ERROR;
		}
	} else {
		return TEST_ERROR;
	}

	return TEST_SUCCESS;
}

double SdkFunction::GetLineSpeed() {
	return  get_lin_speed(device_id);
}
