#include "UNIT_INC.h"
#include "SdkFunction.h"
#include "ScriptTester.h"

bool posmove_ra_test = true;
class PosMoveTest : public ::testing::Test {
 private:
	void SetNextTest(bool value) {
		posmove_ra_test = value;
	}
 public: // NOLINT
	virtual void SetUp() {
		SdkFunction::GetInstance()->SetCopyDbCommend(SdkFunction::kPosMoveTest, posmove_ra_test);
		SdkFunction::GetInstance()->CheckHRSSRobotType(SdkFunction::kPosMoveTest, posmove_ra_test);
		SdkFunction::GetInstance()->SetMotionState(SdkFunction::kOpen);
		SdkFunction::GetInstance()->JogHome();
	}

	virtual void TearDown() {
		SetNextTest(false);
	}
};

TEST_F(PosMoveTest, RAPosMoveTest) {
	ScriptTester scripttester;
	//use unique_ptr to avoid forgeting delete
	unique_ptr<ScriptTest> task(scripttester.CreateTest(SdkFunction::SQA::kPosMoveTest, kUserSet));
	ASSERT_EQ(task->GetResult(), TEST_SUCCESS);
}

TEST_F(PosMoveTest, RSPosMoveTest) {
	ScriptTester scripttester;
	//use unique_ptr to avoid forgeting delete
	unique_ptr<ScriptTest> task(scripttester.CreateTest(SdkFunction::SQA::kPosMoveTest, kUserSet));
	ASSERT_EQ(task->GetResult(), TEST_SUCCESS);
}