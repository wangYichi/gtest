#pragma once
#ifndef SDK_FUNCTION_H
#define SDK_FUNCTION_H

#include "HRSDK.h"
#include "Modbus.h"
#include "GTestCout.h"
#include <Windows.h>
#include <sys/stat.h>
#include <time.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#define IP "127.0.0.1"

#define LOCAL_PORT 502
#define MAX_WAITING_TIME 60
#define NO_ALARM 300
#define POSITION_ERROR 0.01
#define CONNECT_COUNT 25
#define HRB_TEST_COUNT 100
#define DIO_START 1
#define DIO_END 10
#define RSR 0
#define HRB_NAME "Auto_test.hrb"
#define RS410_600_200_LU "RS410-600-200-LU"
#define RS405_500_200_LU "RS405-500-200-LU"
#define RS405_400_200_LU "RS405-400-200-LU"
#define RA605_710_GC "RA605-710-GC"

using namespace std;

class SdkFunction {
 public:
	enum SQA {
		kT4815,
		kT4884,
		kT4817,
		kT5587,
		kT5717,
		kT5462,
		kT6083,
		kT6370,
		kItalySpeedTest,
		kShutdownTest,
		kCreateFolderTest,
		kStartStopPauseTest,
		kSpeedTest,
		kDegreeMoveTest,
		kPosMoveTest,
	};

	enum HRSSVersion {
		kHRSS33,
		kHRSS40,
	};

	enum OperationMode {
		kT1,
		kAUT,
		kT2,
		kEXT,
		kSDKSafety,
		kSDKAuto,
	};

	enum RobotType {
		kRA_Series,
		kRS_Series,
	};

	enum MotionState {
		kClose,
		kOpen,
	};

	SdkFunction();
	~SdkFunction();
	static SdkFunction* GetInstance() {
		static SdkFunction instance_;
		return &instance_;
	}

	vector<vector<double>> ReadCsv(string);
	void SetScriptName(SQA);
	void SetCopyDbCommend(SQA, bool = false);
	void SetUserAlarmMessage(int, string);
	void OpenHRSS();
	void CloseHRSSCrash();
	void CloseByTcpClient();
	void SetLineSpeed(double);
	void SetAccTime(double time);
	void TcpClientWriteCoil(uint16_t, bool);
	void TcpClientReadInputs(uint16_t, uint16_t, bool*);
	void TcpClientSetSpeedRatio(int);
	void TcpClientJog(JointCoordinates, SpaceOperationDirection, int);
	bool TcpClientJogHome();
	void GetCurrentRpm(double*);
	void GetExtCurrentRpm(double*);
	void GetExtCurrentPos(double*);

	template<class T>
	bool IsPositionEqual(T[], T[], bool) const;
	bool OpenConnection();
	bool SetOperationMode(OperationModes);
	bool ReConnection();
	bool DirExists(string);
	bool CheckHRSSRobotType(SQA, bool = false);
	bool SetDiValue(int, bool);
	bool PTPAxisCheck(int, double*);
	bool PTPPosCheck(int, double*);
	bool PTPAxis(int, double*);
	bool LineAxisCheck(int, int, double*);
	bool LinePosCheck(int, double, double*);
	bool LinePos(int, double, double*, bool);
	bool WaitAxisArrived(double*);
	bool ConnectByTcpClient();
	bool MotionHold();
	bool MotionContinue();
	bool CreateFolder(char*);
	bool DeleteFolder(char*);
	bool IsRaSeries();
	//bool SetHrssMode(OperationMode);
	int SetOverrideRatio(int);
	int GetHRSSVersion();
	int GetRobotType();
	int GetHRSSMode();
	int ClearAlarm();
	int SetCounterInital();
	int SetCounter(int, int);
	int SetDoInital();
	int GetDoValue(int);
	int SetDiInital();
	int SetHRSSHrb();
	int StartHRSSHrb();
	int ExtStartHRSSHrb();
	int StopHRSSHrb();
	int TaskHold();
	int TaskContinue();
	int GetCounterValue(int);
	int GetCurrentPosition(double*);
	int GetCurrentJoint(double*);
	int JogHome();
	int SetRSR(int);
	int SetMobusServerConfig(char*, char*, int);
	int OpenMobusServer(int, bool);
	int MobusClientConnection(int, bool);
	int SetMobusClientConfig(int, int, char*, int,
	                         int, int, int, int, int,
	                         int, int, int);
	int SetTrackEncoderSimulation(bool);
	int SetTrackTriggerSimulation(bool);
	int Jog(SpaceOperationTypes, int, SpaceOperationDirection, int);
	int GetOverrideRatio();
	int GetMotionState();
	int SetMotionState(MotionState);
	int T6083ExtSetting();
	double GetLineSpeed();

 private:
	void CopyDB();
	void CloseHRSS();
	bool WaitForStopMotion();
	bool is_connected = false;
	bool is_ra = false;
	double rs_joint_home[4] = { 0.0 };
	double ra_joint_home[6] = { 0.0, 0.0, 0.0, 0.0, -90.0, 0.0 };
	HRSSVersion hrss_version = kHRSS33;
	modbus mb = modbus(IP, LOCAL_PORT);
	string commend = "";
	string robot_type = "";
	string message = "";
	char script_name[50];
	int device_id = -1;
	const int mobus_id = 1;
};
#endif // !SDKFUNCTION_H