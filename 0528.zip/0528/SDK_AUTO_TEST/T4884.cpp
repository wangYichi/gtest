#include "UNIT_INC.h"
#include "SdkFunction.h"
#include "ScriptTester.h"

class TEST_T4884 : public ::testing::Test {
 public: // NOLINT
	virtual void SetUp() {
		SdkFunction::GetInstance()->SetScriptName(SdkFunction::kT4884);
		SdkFunction::GetInstance()->SetCopyDbCommend(SdkFunction::kT4884);
		SdkFunction::GetInstance()->CheckHRSSRobotType(SdkFunction::kT4884);
		SdkFunction::GetInstance()->SetCounterInital();
		SdkFunction::GetInstance()->SetDoInital();
		SdkFunction::GetInstance()->JogHome();
		SdkFunction::GetInstance()->SetHRSSHrb();
		SdkFunction::GetInstance()->StartHRSSHrb();
	}

	virtual void TearDown() {
		SdkFunction::GetInstance()->SetCounterInital();
		SdkFunction::GetInstance()->StopHRSSHrb();
	}
};

TEST_F(TEST_T4884, DoErrorTest) {
	ScriptTester scripttester;
	//use unique_ptr to avoid forgeting delete
	unique_ptr<ScriptTest> task(scripttester.CreateTest(SdkFunction::SQA::kT4884, kTime));
	ASSERT_EQ(task->GetResult(), TEST_SUCCESS);
}