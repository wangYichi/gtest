#include "Script.h"
#include "SdkFunction.h"

class ScriptTester {
 public:
	ScriptTest *CreateTest(SdkFunction::SQA test, PassCondition condition, bool second_test = false) {
		switch (test) {
		case SdkFunction::SQA::kT4815:
			return new StartPause(condition);
			break;
		case SdkFunction::SQA::kT4817:
			return new ModbusHankShake(condition);
			break;
		case SdkFunction::SQA::kT4884:
			return new DoError(condition);
			break;
		case SdkFunction::SQA::kT5717:
			return new CnvTest(condition);
			break;
		case SdkFunction::SQA::kT5462:
			return new CheckSpeedRatioTest(condition);
			break;
		case SdkFunction::SQA::kT5587:
			return new SingularityTest(condition);
			break;
		case SdkFunction::SQA::kT6083:
			return new ExtSpeedTest(condition, second_test);
			break;
		case SdkFunction::SQA::kT6370:
			return new CheckA6Dgree(condition);
			break;
		case SdkFunction::SQA::kItalySpeedTest:
			return new CalculateRunTime(condition);
			break;
		case SdkFunction::SQA::kShutdownTest:
			return new Shutdown(condition);
			break;
		case SdkFunction::SQA::kCreateFolderTest:
			return new CreateFolder(condition);
			break;
		case SdkFunction::SQA::kStartStopPauseTest:
			return new StartStopPause(condition);
			break;
		case SdkFunction::SQA::kSpeedTest:
			return new ModifySpeed(condition);
			break;
		case SdkFunction::SQA::kDegreeMoveTest:
			return new DegreeMove(condition);
			break;
		case SdkFunction::SQA::kPosMoveTest:
			return new PosMove(condition);
			break;
		default:
			return NULL;
			break;
		}
	}
};
