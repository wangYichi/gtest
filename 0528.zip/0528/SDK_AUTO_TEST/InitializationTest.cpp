#include "UNIT_INC.h"
#include "SdkFunction.h"

class InitializationTest : public ::testing::Test {
 public: // NOLINT
	virtual void SetUp() {
	}

	virtual void TearDown() {
	}
};

TEST(InitializationTest, CheckSQAFolder) {
	ASSERT_TRUE(SdkFunction::GetInstance()->DirExists("SQA"));
}

TEST(InitializationTest, HRSSConnect) {
	ASSERT_TRUE(SdkFunction::GetInstance()->OpenConnection());
}

TEST(InitializationTest, CheckHRSSExtMode) {
	ASSERT_EQ(SdkFunction::GetInstance()->GetHRSSMode(), SdkFunction::kEXT);
}

TEST(InitializationTest, ClearAlarm) {
	SdkFunction::GetInstance()->ClearAlarm();
}

TEST(InitializationTest, GetHRSSVersion) {
	ASSERT_TRUE(!SdkFunction::GetInstance()->GetHRSSVersion());
}

TEST(InitializationTest, GetRobotType) {
	ASSERT_EQ(SdkFunction::GetInstance()->GetRobotType(), TEST_SUCCESS);
}