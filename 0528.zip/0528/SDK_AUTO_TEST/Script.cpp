#include "Script.h"
#include "SdkFunction.h"

bool StartPause::GetResult() {

	return true;
}