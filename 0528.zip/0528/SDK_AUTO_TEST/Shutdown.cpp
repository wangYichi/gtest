#include "UNIT_INC.h"
#include "SdkFunction.h"
#include "ScriptTester.h"

class ShutdownTest : public ::testing::Test {
 public: // NOLINT
	virtual void SetUp() {

	}

	virtual void TearDown() {

	}
};

TEST_F(ShutdownTest, RestartHRSS) {
	ScriptTester scripttester;
	//use unique_ptr to avoid forgeting delete
	unique_ptr<ScriptTest> task(scripttester.CreateTest(SdkFunction::SQA::kShutdownTest, kTime));
	ASSERT_EQ(task->GetResult(), TEST_SUCCESS);
}