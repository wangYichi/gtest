#include "SdkFunction.h"
#include "UNIT_INC.h"

enum PassCondition {
	kCount,
	kTime,
	kUserSet,
};

class ScriptTest {
 protected:
	int pass_condition = 0;
	void SwitchPassCondition(PassCondition condition, int value = 1) {
		switch (condition) {
		case kCount:
			pass_condition = HRB_TEST_COUNT * value; // 100 per test
			break;
		case kTime:
			pass_condition = MAX_WAITING_TIME * value; // 60 SEC per test
			break;
		case kUserSet:
			pass_condition = value;
		default:
			pass_condition = 0;
			break;
		}
	}
 public:
	virtual bool GetResult() = 0;
};

class StartPause : public ScriptTest {
 private:
	double robot_position[6] { 0 };
	const double p1[6] = { 400.0, 320.0, -10.0, .0, .0, .0 };
	double check_z_position = -100.0;
	bool pause_flag = false;
	time_t begin_time, end_time, wait_time = 0;
 public:
	StartPause(PassCondition condition) {
		SwitchPassCondition(condition, 20);
	}

	bool GetResult() override {
		time(&begin_time);

		while (wait_time < pass_condition) {
			wait_time = difftime(time(&end_time), begin_time);
			SdkFunction::GetInstance()->GetCurrentPosition(robot_position);
			if (robot_position[0] >= p1[0] && !pause_flag && robot_position[2] >= -10.0) {
				SdkFunction::GetInstance()->TaskHold();
				Sleep(1000);
				SdkFunction::GetInstance()->TaskContinue();
				pause_flag = true;
			}

			if (robot_position[2] == check_z_position && pause_flag) {
				pause_flag = false;
			}

			if (robot_position[2] < check_z_position) {
				return TEST_ERROR;
			}
		}

		return TEST_SUCCESS;
	};
};

class DoError : public ScriptTest {
 private:
	time_t begin_time, end_time, wait_time = 0;
	int test_time = 2;
 public:
	DoError(PassCondition condition) {
		SwitchPassCondition(condition, 2);
	}

	bool GetResult() override {
		time(&begin_time);
		while (wait_time < pass_condition) {
			wait_time = difftime(time(&end_time), begin_time);
			if (SdkFunction::GetInstance()->GetCounterValue(1) > 1) {

				return TEST_ERROR;
			}
		}
		return TEST_SUCCESS;
	}
};

class SingularityTest : public ScriptTest {
 private:
	double pos[6] = { -10.0, 0.0, -10.0, 0.0, 0.0, 0.0 };
	double robot_position[6] = { 0 };
	double test_time = 2.0;
 public:
	SingularityTest(PassCondition condition) {
		SwitchPassCondition(condition);
	}

	bool GetResult() override {
		SdkFunction::GetInstance()->ExtStartHRSSHrb();
		SdkFunction::GetInstance()->WaitAxisArrived(pos);

		while (SdkFunction::GetInstance()->GetCounterValue(1) < pass_condition) {
			SdkFunction::GetInstance()->GetCurrentJoint(robot_position);

			if (SdkFunction::GetInstance()->ClearAlarm() == NO_ALARM) {
				SdkFunction::GetInstance()->ExtStartHRSSHrb();
			}

			if (!SdkFunction::GetInstance()->IsPositionEqual(robot_position, pos, false)) {
				return TEST_ERROR;
			}
		}
		return TEST_SUCCESS;
	}
};

class CnvTest : public ScriptTest {
 private:
	time_t begin_time, end_time, wait_time = 0;

 public:
	CnvTest(PassCondition condition) {
		SwitchPassCondition(condition);
	}

	bool GetResult() override {
		SdkFunction::GetInstance()->StartHRSSHrb();
		time(&begin_time);
		while (wait_time < pass_condition) {
			wait_time = difftime(time(&end_time), begin_time);
			if (SdkFunction::GetInstance()->ClearAlarm() == 110) {
				return TEST_ERROR;
			}
		}
		return TEST_SUCCESS;
	}
};

class CheckSpeedRatioTest : public ScriptTest {
 private:
	int test_count = 0;
	int speed_ratio = 15;
	time_t begin_time, end_time, wait_time = 0;

 public:
	CheckSpeedRatioTest(PassCondition condition) {
		SwitchPassCondition(condition);
	}

	bool GetResult() override {
		if (!SdkFunction::GetInstance()->ConnectByTcpClient()) {
			return TEST_ERROR;
		}

		if (SdkFunction::GetInstance()->TcpClientJogHome()) {
			return TEST_ERROR;
		}

		SdkFunction::GetInstance()->TcpClientSetSpeedRatio(speed_ratio);

		time(&begin_time);
		while (wait_time < pass_condition) {
			wait_time = difftime(time(&end_time), begin_time);
			SdkFunction::GetInstance()->TcpClientJog(kJoint1, kPositive, 3);
			SdkFunction::GetInstance()->TcpClientJogHome();

			if (SdkFunction::GetInstance()->GetOverrideRatio() != speed_ratio) {
				return TEST_ERROR;
			}
		}
		SdkFunction::GetInstance()->CloseByTcpClient();
		return TEST_SUCCESS;
	}
};

class CheckA6Dgree : public ScriptTest {
 private:
	bool is_a6_0 = false;
	bool is_a6_360 = false;
	double position_0[6] = { 0.0, 0.0, 0.0, 0.0, -90.0, 0.0 };
	double position_360[6] = { 0.0, 0.0, 0.0, 0.0, -90.0, 360.0 };
	double robot_position[6] = { 0 };
	int test_count = 0;
	time_t begin_time, end_time, wait_time = 0;
 public:
	CheckA6Dgree(PassCondition condition) {
		SwitchPassCondition(condition);
	}

	bool GetResult() override {
		time(&begin_time);
		SdkFunction::GetInstance()->StartHRSSHrb();
		while (wait_time < pass_condition) {
			SdkFunction::GetInstance()->GetCurrentJoint(robot_position);
			wait_time = difftime(time(&end_time), begin_time);
			if (SdkFunction::GetInstance()->IsPositionEqual(robot_position, position_360, true)) {
				is_a6_360 = true;
			} else {
				is_a6_360 = false;
			}

			if (SdkFunction::GetInstance()->IsPositionEqual(robot_position, position_0, true)) {
				is_a6_0 = true;
			} else {
				is_a6_0 = false;
			}

			if (!is_a6_0 && is_a6_360) {
				test_count += 1;
				SdkFunction::GetInstance()->StartHRSSHrb();
				if (test_count > 200) {
					return TEST_ERROR;
				}
			} else {
				test_count = 0;
			}
		}
		return TEST_SUCCESS;
	}
};

class ModbusHankShake : public ScriptTest {
 private:
	time_t begin_time, end_time, wait_time = 0;
	int read_index = 14;
	bool coils[256] = { 0 };
	bool inputs[256] = { 0 };
	int SI_index = 0;
	string message = "";
	void SetSI(int index, bool value) {
		SdkFunction::GetInstance()->TcpClientWriteCoil(8 + index, value);
	}

	void ResetSI() {
		for (int i = 0; i <= 19; i++) {
			Sleep(20);
			SdkFunction::GetInstance()->TcpClientWriteCoil(8 + i, false);
		}
	}

 public:
	ModbusHankShake(PassCondition condition) {
		SwitchPassCondition(condition, 480);
		if (!SdkFunction::GetInstance()->ConnectByTcpClient()) {
			GCOUTERROR("Connect Tcp Client fail!");
		}
		ResetSI();
	}

	bool GetResult() override {
		SdkFunction::GetInstance()->StartHRSSHrb();
		Sleep(500);
		time(&begin_time);

		while (wait_time < pass_condition) {
			wait_time = difftime(time(&end_time), begin_time);
			//Read HRSS SO
			SdkFunction::GetInstance()->TcpClientReadInputs(0, 256, inputs);

			if (inputs[14] && SI_index <= 19) {
				cout << "SI_index :" << SI_index + 9 << endl;
				Sleep(900);
				SetSI(SI_index, true);
				SI_index += 1;
				Sleep(100);
			}

			if (SdkFunction::GetInstance()->GetCounterValue(2) && SI_index > 0) {
				cout << "clear" << endl;
				ResetSI();
				SI_index = 0;
				Sleep(300);
			}

			if (SdkFunction::GetInstance()->ClearAlarm() != 300) {
				message = "Test count: " + to_string(SdkFunction::GetInstance()->GetCounterValue(1));
				GCOUTERROR(message);
				return TEST_ERROR;
			}
		}
		return TEST_SUCCESS;
	}
};

class CalculateRunTime : public ScriptTest {
 private:
	time_t begin_time, end_time, wait_time = 0;
	string file_name = "SQA\\ItelySpeedTest\\SV.csv", message = "";
	vector<vector<double>> point_array;
	double init_pos[6] = { 40.0, -80.0, 0.0, -70.0, 0.0, 0.0 };
	double temp_pos[6] = { 0 };
	double current_pos[6] = { 0 };
	bool test_1 = false;
	bool test_2 = false;

 public:
	CalculateRunTime(PassCondition condition) {
		SwitchPassCondition(condition);
	}

	bool GetResult() override {
		point_array = SdkFunction::GetInstance()->ReadCsv(file_name);
		SdkFunction::GetInstance()->SetLineSpeed(4000);
		SdkFunction::GetInstance()->SetAccTime(40);
		SdkFunction::GetInstance()->SetOverrideRatio(100);

		//test 1
		SdkFunction::GetInstance()->PTPAxisCheck(0, init_pos);
		time(&begin_time);
		for (int i = 0; i < point_array.size(); i++) {
			temp_pos[0] = point_array[i][0];
			temp_pos[1] = point_array[i][1];
			temp_pos[5] = point_array[i][2];
			SdkFunction::GetInstance()->LinePosCheck(0, 0, temp_pos);
		}
		wait_time = difftime(time(&end_time), begin_time);
		message = "haven't motion_hold time(s): " + to_string(wait_time);
		GCOUT(message);

		//test 2
		//SdkFunction::GetInstance()->JogHome();
		SdkFunction::GetInstance()->PTPAxisCheck(0, init_pos);
		SdkFunction::GetInstance()->MotionHold();
		for (int i = 0; i < point_array.size(); i++) {
			temp_pos[0] = point_array[i][0];
			temp_pos[1] = point_array[i][1];
			temp_pos[5] = point_array[i][2];
			SdkFunction::GetInstance()->LinePos(1, 100, temp_pos, true);
		}
		SdkFunction::GetInstance()->MotionContinue();
		time(&begin_time);

		do {
			SdkFunction::GetInstance()->GetCurrentPosition(current_pos);
		} while (!SdkFunction::GetInstance()->IsPositionEqual(current_pos, temp_pos, true));
		wait_time = difftime(time(&end_time), begin_time);
		message = "have motion_hold time(s): " + to_string(wait_time);
		GCOUT(message);

		return TEST_SUCCESS;
	}
};

class ExtSpeedTest : public ScriptTest {
 private:
	enum step {
		None,
		HRB_PTP_Robot,
		HRB_LIN_Robot,
		HRB_PTP_External_Axis,
		HRB_ASYPTP_External_Axis,
		HRB_LIN_External_Axis,
		HRB_CMD_External_Axis_Set_Speed,
	};

	int axis_num = 6;
	bool unit_second_test = false;
	const double tolerance = 0.1;
	const double ra_t1_check_para[10] = { 450.0, 250.0, 750.0, 9.375, 750.0, 9.375, 750.0, 5.0, 300.0, 5.0 };
	const double rs_t1_check_para[10] = { 300.0, 250.0, 750.0, 9.375, 750.0, 9.375, 750.0, 5.0, 300.0, 5.0 };
	const double ra_auto_check_para[10] = { 3000, 500.0, 5000.0, 62.5, 5000.0, 62.5, 3000.183, 15.627, 300.0, 8.333 };
	const double rs_auto_check_para[10] = { 4500, 500.0, 5000.0, 62.5, 5000.0, 62.5, 3000.183, 15.627, 300.0, 8.333 };
	double answer[10] = { 0.0 };
	double pos[6] = { 0.0 };

	bool compare_number(double num1, double num2) {
		return fabs(num1 - num2) > 1;
	}

	bool GetTestAnswer(OperationModes mode) {
		SdkFunction::GetInstance()->SetCounter(1, HRB_PTP_Robot);
		string message = "";
		int test_number = 1;
		double compare_data[10];
		double axis_rpm[6] = { 0.0 };
		double ext_rpm[3] = { 0.0 };
		double ext_pos[3] = { 0.0 };
		double line_speed = 0.0;
		bool e1_0 = false, e2_0 = false, next = false;

		if (mode == kManual) {
			if (axis_num == 4) {
				memcpy(compare_data, rs_t1_check_para, 10 * sizeof(double));
			} else {
				memcpy(compare_data, ra_t1_check_para, 10 * sizeof(double));
			}
		} else {
			if (axis_num == 4) {
				memcpy(compare_data, rs_auto_check_para, 10 * sizeof(double));
			} else {
				memcpy(compare_data, ra_auto_check_para, 10 * sizeof(double));
			}
		}

		//SdkFunction::GetInstance()->SetCounter(1, 4);

		while (test_number != 0) {
			if (SdkFunction::GetInstance()->ClearAlarm() != 300) {
				return TEST_ERROR;
			}
			test_number = SdkFunction::GetInstance()->GetCounterValue(1);
			SdkFunction::GetInstance()->GetExtCurrentRpm(ext_rpm);
			SdkFunction::GetInstance()->GetExtCurrentPos(ext_pos);

			if (fabs(ext_pos[0] - 0.0) <= tolerance && !e1_0) {
				e1_0 = true;
			}

			if (fabs(ext_pos[1] - 0.0) <= tolerance && !e2_0) {
				e2_0 = true;
			}

			if (test_number == HRB_PTP_Robot) {
				SdkFunction::GetInstance()->GetCurrentRpm(axis_rpm);
				SdkFunction::GetInstance()->GetCurrentJoint(pos);
				answer[HRB_PTP_Robot - 1] = axis_rpm[axis_num - 1] > answer[HRB_PTP_Robot - 1] ?
				                            axis_rpm[axis_num - 1] : answer[HRB_PTP_Robot - 1];

				if (fabs(pos[axis_num - 1] - 360.0) <= tolerance) {
					SdkFunction::GetInstance()->SetCounter(1, HRB_LIN_Robot);
				}

			} else if (test_number == HRB_LIN_Robot) {
				SdkFunction::GetInstance()->GetCurrentPosition(pos);
				if (SdkFunction::GetInstance()->GetCounterValue(2) == 101) {
					line_speed = SdkFunction::GetInstance()->GetLineSpeed();
					answer[HRB_LIN_Robot - 1] = line_speed > answer[HRB_LIN_Robot - 1] ?
					                            line_speed : answer[HRB_LIN_Robot - 1];
					e1_0 = false;
					e2_0 = false;
					next = false;
					SdkFunction::GetInstance()->SetCounter(1, HRB_PTP_External_Axis);
				}
			} else if (test_number == HRB_PTP_External_Axis) {

				if (SdkFunction::GetInstance()->GetCounterValue(2) == 100) {

					answer[HRB_PTP_External_Axis - 1] = ext_rpm[0] > answer[HRB_PTP_External_Axis - 1] ?
					                                    ext_rpm[0] : answer[HRB_PTP_External_Axis - 1];

					if (fabs(ext_pos[0] - 1000.0) <= tolerance && e1_0) {
						next = true;
					}
				} else if (SdkFunction::GetInstance()->GetCounterValue(2) == 101 && next) {

					answer[HRB_PTP_External_Axis] = ext_rpm[1] > answer[HRB_PTP_External_Axis] ?
					                                ext_rpm[1] : answer[HRB_PTP_External_Axis];

					if (fabs(ext_pos[1] - 360.0) <= tolerance && e2_0) {
						e1_0 = false;
						e2_0 = false;
						next = false;
						SdkFunction::GetInstance()->SetCounter(1, HRB_ASYPTP_External_Axis);
					}
				}

			} else if (test_number == HRB_ASYPTP_External_Axis) {

				if (SdkFunction::GetInstance()->GetCounterValue(2) == 100) {
					answer[HRB_ASYPTP_External_Axis] = ext_rpm[0] > answer[HRB_ASYPTP_External_Axis] ?
					                                   ext_rpm[0] : answer[HRB_ASYPTP_External_Axis];

					if (fabs(ext_pos[0] - 1000.0) <= tolerance && e1_0) {
						next = true;
					}
				} else if (SdkFunction::GetInstance()->GetCounterValue(2) == 101 && next) {
					answer[HRB_ASYPTP_External_Axis + 1] = ext_rpm[1] > answer[HRB_ASYPTP_External_Axis + 1] ?
					                                       ext_rpm[1] : answer[HRB_ASYPTP_External_Axis + 1];

					if (fabs(ext_pos[1] - 360.0) <= tolerance && e2_0) {
						e1_0 = false;
						e2_0 = false;
						next = false;
						SdkFunction::GetInstance()->SetCounter(1, HRB_LIN_External_Axis);
					}
				}

			} else if (test_number == HRB_LIN_External_Axis) {

				if (SdkFunction::GetInstance()->GetCounterValue(2) == 100) {

					answer[HRB_LIN_External_Axis + 1] = ext_rpm[0] > answer[HRB_LIN_External_Axis + 1] ?
					                                    ext_rpm[0] : answer[HRB_LIN_External_Axis + 1];

					if (fabs(ext_pos[0] - 1000.0) <= tolerance && e1_0) {
						next = true;
					}
				} else if (SdkFunction::GetInstance()->GetCounterValue(2) == 101 && next) {

					answer[HRB_LIN_External_Axis + 2] = ext_rpm[1] > answer[HRB_LIN_External_Axis + 2] ?
					                                    ext_rpm[1] : answer[HRB_LIN_External_Axis + 2];

					if (fabs(ext_pos[1] - 360.0) <= tolerance && e2_0) {
						e1_0 = false;
						e2_0 = false;
						next = false;
						SdkFunction::GetInstance()->SetCounter(1, HRB_CMD_External_Axis_Set_Speed);
					}
				}

			} else if (test_number == HRB_CMD_External_Axis_Set_Speed) {

				if (SdkFunction::GetInstance()->GetCounterValue(2) == 100) {

					answer[HRB_CMD_External_Axis_Set_Speed + 2] = ext_rpm[0] > answer[HRB_CMD_External_Axis_Set_Speed + 2] ?
					    ext_rpm[0] : answer[HRB_CMD_External_Axis_Set_Speed + 2];

					if (fabs(ext_pos[0] - 500.0) <= tolerance && e1_0) {
						next = true;
					}
				} else if (SdkFunction::GetInstance()->GetCounterValue(2) == 101 && next) {

					answer[HRB_CMD_External_Axis_Set_Speed + 3] = ext_rpm[1] > answer[HRB_CMD_External_Axis_Set_Speed + 3] ?
					    ext_rpm[1] : answer[HRB_CMD_External_Axis_Set_Speed + 3];

					if (fabs(ext_pos[1] - 180.0) <= tolerance && e2_0) {
						e1_0 = false;
						e2_0 = false;
						next = false;
						SdkFunction::GetInstance()->SetCounter(1, None);
					}
				}
			}
		}

		message = "\nRobot PTP Speed: " + to_string(answer[0]) + " / " + to_string(compare_data[0]) + "\n"
		          + "Robot LIN Speed: " + to_string(answer[1]) + " / " + to_string(compare_data[1]) + "\n"
		          + "Linear External Axis PTP Test: " + to_string(answer[2]) + " / " + to_string(compare_data[2]) + "\n"
		          + "Rotary External Axis PTP Test: " + to_string(answer[3]) + " / " + to_string(compare_data[3]) + "\n"
		          + "Linear External Axis ASYPTP Test: " + to_string(answer[4]) + " / " + to_string(compare_data[4]) + "\n"
		          + "Rotary External Axis ASYPTP Test: " + to_string(answer[5]) + " / " + to_string(compare_data[5]) + "\n"
		          + "Linear External Axis Line Test: " + to_string(answer[6]) + " / " + to_string(compare_data[6]) + "\n"
		          + "Rotary External Axis Line Test: " + to_string(answer[7]) + " / " + to_string(compare_data[7]) + "\n"
		          + "Linear External Axis CMD Test: " + to_string(answer[8]) + " / " + to_string(compare_data[8]) + "\n"
		          + "Rotary External Axis CMD Test: " + to_string(answer[9]) + " / " + to_string(compare_data[9]) + "\n";

		GCOUT(message);
		bool check = false;
		for (int i = 0; i <= 10; i++) {
			bool num_check = compare_number(answer[i], compare_data[i]);
			check = check || num_check;
		}
		return check;
	}

 public:
	ExtSpeedTest(PassCondition condition, bool second_test) {
		SwitchPassCondition(condition);
		unit_second_test = second_test;
		if (second_test) {
			axis_num = 4;
		} else {
			axis_num = 6;
		}
	}

	bool GetResult() override {
		bool t1_test = TEST_ERROR, aut_test = TEST_ERROR;
		cout << boolalpha;
		//mode T1
		SdkFunction::GetInstance()->SetOperationMode(kManual);
		Sleep(1000);
		SdkFunction::GetInstance()->StartHRSSHrb();

		t1_test = GetTestAnswer(kManual);
		cout << "t1_test: " << t1_test << boolalpha << endl;

		Sleep(1000);
		//mode AUTO
		SdkFunction::GetInstance()->SetOperationMode(kAuto);
		Sleep(1000);
		SdkFunction::GetInstance()->StartHRSSHrb();

		aut_test = GetTestAnswer(kAuto);
		cout << "aut_test: " << aut_test << boolalpha << endl;

		return t1_test || aut_test;
	}
};

class Shutdown : public ScriptTest {
 private:
	time_t begin_time, end_time, wait_time = 0;
	int restart = 0;
	bool check = false;
 public:
	Shutdown(PassCondition condition) {
		SwitchPassCondition(condition, 4320);
	}

	bool GetResult() override {
		time(&begin_time);
		while (wait_time < pass_condition) {
			wait_time = difftime(time(&end_time), begin_time);

			if (check) {
				SdkFunction::GetInstance()->SetDiValue(15, true);
				restart += 1;
				Sleep(1000 * 60 * 5);
				cout << "Restart:" << restart << endl;
				check = false;
			} else {
				check = SdkFunction::GetInstance()->ReConnection();
				Sleep(100);
			}
		}
		return TEST_SUCCESS;
	}
};

class CreateFolder : public ScriptTest {
 private:
	char* folder_name = "Test";
	string check_folder = "../Program/" + string(folder_name);
 public:
	CreateFolder(PassCondition condition) {
		SwitchPassCondition(condition);
	}

	~CreateFolder() {
		delete[] folder_name;
	}

	bool GetResult() override {
		if (SdkFunction::GetInstance()->CreateFolder(folder_name)) {
			return TEST_ERROR;
		}
		Sleep(1000);
		int check = SdkFunction::GetInstance()->DirExists(check_folder);
		SdkFunction::GetInstance()->DeleteFolder(folder_name);
		return !check;
	}
};

class StartStopPause : public ScriptTest {
 private:
	bool start_test = false;
	bool stop_test = false;
	bool pause_test = false;
	int mode = kIdle;

	void StartTest() {
		if (mode == kIdle) {
			SdkFunction::GetInstance()->StartHRSSHrb();
			Sleep(3000);
			mode = SdkFunction::GetInstance()->GetMotionState();
			start_test = (mode == kMoving) ? true : false;
			cout << boolalpha << start_test << endl;
		}
	}

	void PauseTest() {
		if (mode == kMoving) {
			SdkFunction::GetInstance()->TaskHold();
			Sleep(3000);
			mode = SdkFunction::GetInstance()->GetMotionState();
			pause_test = (mode == kHold) ? true : false;
			cout << boolalpha << pause_test << endl;
		}
	}

	void StopTest() {
		if (mode == kHold) {
			SdkFunction::GetInstance()->StopHRSSHrb();
			Sleep(3000);
			mode = SdkFunction::GetInstance()->GetMotionState();
			stop_test = (mode == kIdle) ? true : false;
			cout << boolalpha << stop_test << endl;
		}
	}
 public:
	StartStopPause(PassCondition condition) {
		SwitchPassCondition(condition);
	}

	bool GetResult() override {
		mode = SdkFunction::GetInstance()->GetMotionState();
		StartTest();
		PauseTest();
		StopTest();

		return !(start_test || stop_test || pause_test);
	}
};

class ModifySpeed : public ScriptTest {
 private:
	string message = "";
 public:
	ModifySpeed(PassCondition condition) {
		SwitchPassCondition(condition);
	}

	bool GetResult() override {
		SdkFunction::GetInstance()->StartHRSSHrb();
		Sleep(1000);
		int mode = SdkFunction::GetInstance()->GetMotionState();
		if (mode == kMoving) {
			for (int i = 10; i < 100; i += 10) {
				SdkFunction::GetInstance()->SetOverrideRatio(i);
				message = "SetOverrideRatio: " + i;
				GCOUT(message);
				Sleep(500);
				if (SdkFunction::GetInstance()->GetOverrideRatio() != i) {
					return TEST_ERROR;
				}
			}

			for (int i = 100; i > 0; i -= 10) {
				SdkFunction::GetInstance()->SetOverrideRatio(i);
				message = "SetOverrideRatio: " + i;
				GCOUT(message);
				Sleep(500);
				if (SdkFunction::GetInstance()->GetOverrideRatio() != i) {
					return TEST_ERROR;
				}
			}
		}

		return TEST_SUCCESS;
	}
};

class DegreeMove : public ScriptTest {
 private:
	double pos_axis[6] = { 0 };
	double home[6] = { 15.0, 15.0, 0.0, 0.0, -90.0, 0.0 };
 public:
	DegreeMove(PassCondition condition) {
		SwitchPassCondition(condition);
	}

	bool GetResult() override {
		if (SdkFunction::GetInstance()->IsRaSeries()) {
			pos_axis[0] = 10.0;
			pos_axis[1] = 0.0;
			pos_axis[2] = 10.0;
			pos_axis[3] = 0.0;
			pos_axis[4] = -90.0;
			pos_axis[5] = 0.0;
		} else {
			pos_axis[0] = 10.0;
			pos_axis[1] = 10.0;
			pos_axis[2] = 0.0;
			pos_axis[3] = 0.0;
			pos_axis[4] = 0.0;
			pos_axis[5] = 0.0;
		}
		bool ptp_test = SdkFunction::GetInstance()->PTPAxisCheck(0, pos_axis);
		SdkFunction::GetInstance()->PTPAxisCheck(0, home);
		bool line_test = SdkFunction::GetInstance()->LineAxisCheck(0, 0, pos_axis);
		Sleep(500);
		return ptp_test || line_test;
	}
};

class PosMove : public ScriptTest {
 private:
	double pos_axis[6] = { 0 };
	double rs_home[6] = { -49.998, 396.485, -5.0, 0.0, 0.0, 10.0 };
 public:
	PosMove(PassCondition condition) {
		SwitchPassCondition(condition);
	}

	bool GetResult() override {
		if (SdkFunction::GetInstance()->IsRaSeries()) {
			pos_axis[0] = -64.413;
			pos_axis[1] = 365.304;
			pos_axis[2] = 352.900;
			pos_axis[3] = -180.000;
			pos_axis[4] = -10.0;
			pos_axis[5] = 100.0;
		} else {
			pos_axis[0] = -98.924;
			pos_axis[1] = 386.028;
			pos_axis[2] = 0.0;
			pos_axis[3] = 0.0;
			pos_axis[4] = 0.0;
			pos_axis[5] = 20.0;
		}
		bool ptp_test = SdkFunction::GetInstance()->PTPPosCheck(0, pos_axis);
		if (SdkFunction::GetInstance()->IsRaSeries()) {
			SdkFunction::GetInstance()->JogHome();
		} else {
			SdkFunction::GetInstance()->PTPPosCheck(0, pos_axis);
		}
		bool line_test = SdkFunction::GetInstance()->LinePosCheck(0, 0, pos_axis);
		Sleep(500);
		return ptp_test || line_test;
	}
};