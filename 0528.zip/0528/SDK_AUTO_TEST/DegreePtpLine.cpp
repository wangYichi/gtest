#include "UNIT_INC.h"
#include "SdkFunction.h"
#include "ScriptTester.h"

bool degreemove_ra_test = true;

class DegreeMoveTest : public ::testing::Test {
 public: // NOLINT
	virtual void SetUp() {
		SdkFunction::GetInstance()->SetCopyDbCommend(SdkFunction::kDegreeMoveTest, degreemove_ra_test);
		SdkFunction::GetInstance()->CheckHRSSRobotType(SdkFunction::kDegreeMoveTest, degreemove_ra_test);
		SdkFunction::GetInstance()->SetMotionState(SdkFunction::kOpen);
		SdkFunction::GetInstance()->JogHome();
	}

	virtual void TearDown() {
		degreemove_ra_test = false;
	}
};

TEST_F(DegreeMoveTest, RADegreeMoveTest) {
	ScriptTester scripttester;
	//use unique_ptr to avoid forgeting delete
	unique_ptr<ScriptTest> task(scripttester.CreateTest(SdkFunction::SQA::kDegreeMoveTest, kUserSet));
	ASSERT_EQ(task->GetResult(), TEST_SUCCESS);
}

TEST_F(DegreeMoveTest, RsDegreeMoveTest) {
	ScriptTester scripttester;
	//use unique_ptr to avoid forgeting delete
	unique_ptr<ScriptTest> task(scripttester.CreateTest(SdkFunction::SQA::kDegreeMoveTest, kUserSet));
	ASSERT_EQ(task->GetResult(), TEST_SUCCESS);
}