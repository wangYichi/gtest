#include "UNIT_INC.h"
#include "SdkFunction.h"
#include "ScriptTester.h"

class ModifySpeedTest : public ::testing::Test {
 public: // NOLINT
	virtual void SetUp() {
		SdkFunction::GetInstance()->JogHome();
		SdkFunction::GetInstance()->SetScriptName(SdkFunction::kSpeedTest);
		SdkFunction::GetInstance()->GetRobotType();
		SdkFunction::GetInstance()->SetCounterInital();
		if (SdkFunction::GetInstance()->IsRaSeries()) {
			SdkFunction::GetInstance()->SetCounter(1, 1);
		} else {
			SdkFunction::GetInstance()->SetCounter(1, 2);
		}
		SdkFunction::GetInstance()->SetHRSSHrb();
	}

	virtual void TearDown() {
		SdkFunction::GetInstance()->SetCounterInital();
		SdkFunction::GetInstance()->StopHRSSHrb();
	}
};

TEST_F(ModifySpeedTest, SpeedTest) {
	ScriptTester scripttester;
	//use unique_ptr to avoid forgeting delete
	unique_ptr<ScriptTest> task(scripttester.CreateTest(SdkFunction::SQA::kSpeedTest, kUserSet));
	ASSERT_EQ(task->GetResult(), TEST_SUCCESS);
}